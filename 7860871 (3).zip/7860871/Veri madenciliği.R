# Temel fonksiyonlar
# Print fonksiyonu ile değer atama
print("ben gonul")

# x değişkenine 7 değerini ata
x <- 7
# x değişkenine  atanan değerin kontrolü
print(x)

# y değişkenine elazıg kelimesini ata
y <- "elazıg"
# y değişkenine  atanan değerin kontrolü
print(y)

# R programlama dilinde basit hesaplama yapma
3+3
3*3
3^3

# yorum işaretidir. sağda olunca yorum yapmak demektir.değerlendirme yapmaz.
# Veri setini çağırma
# önünde değer varsa değerlendirme yapar
3*3 # 

#değer atarken "=" veya "<-" kullanılır. Bznzer işlem yapar.
x = 2 # Same as: x <- 2
print(x)

# data frame ile veri çerçevesini görülmektedir. değişkenin türü nü görmek için 
#class() fonksiyonu içerisine değişkenin adı veya nesnesi girilir. 

class(x)
class(y)

# name ile tam isim ataması yapılır.
name ="gonul kılınc" 
class(name)
name

# c fonksiyonunu kullanma. bu fonksiyon nesneleri birleşitirerek vektör 
oluşturur.
gonul<-c ("hayat, umut, azim")
print(gonul)
class(gonul)

# combine (c) ile ad ve soyad iki ayrı karakter dizisi haline getirip bunları 
# name2 olarak adlandırıp iki elemanlı vektör atama.
name2=c ("gonul","kılınc")
print(name2)

#length() ile nesne uzunluğu ile ayar yapma 
length(x)
length(gonul)
length(name2)

#vektör üzerinde işlem yapma
x*3
x+4
x+c(2,4,6,8)

#sadece sayısal olarak işlem görür. 
name2+5

#değiştirilmiş vektörleri yeni bir vektör olarak kaydetme

y = x + c(4, 8, 10, 12)
print(y)

#str fonksiyonu ile nesne yapısını görme
str(x)
str(name2)
str(y)
# Hocam Basic R dosyası bitti. 




